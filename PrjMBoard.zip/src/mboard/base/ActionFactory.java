package mboard.base;

import mboard.impl.MenuActionList;
import mboard.impl.MenuActionWriteForm;

public class ActionFactory {
	
	public  Action  getAction(String command) {
		
		Action   action = null;
		switch (command) {
		// Menu
		case "MENULIST":   // 메뉴록록
			action     =  new  MenuActionList();
			break;
		case  "MENUWRITEFORM": // 새메뉴입력
			action   =  new  MenuActionWriteForm();
			break;
		case  "MENUWRITE":     // 메누저장하기
			//action   =  new  MenuActionWrite();
			break;
			
		
		// Board
		case "LIST":
			//action   =  new  BoardActionList();   

		default:
			break;
		}
		
		return action;
		
	} 
	
}






